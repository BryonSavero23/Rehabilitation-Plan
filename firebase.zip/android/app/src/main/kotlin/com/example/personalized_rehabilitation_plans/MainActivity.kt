package com.example.personalized_rehabilitation_plans

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
