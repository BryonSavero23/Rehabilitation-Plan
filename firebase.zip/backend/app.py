from flask import Flask, request, jsonify
import pandas as pd
import numpy as np
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import OneHotEncoder
import joblib
import uuid
import os
import shutil
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# Create directories for models if they don't exist
os.makedirs('models', exist_ok=True)

# Sample data for training the model
def generate_sample_data():
    body_parts = ['Knee', 'Shoulder', 'Ankle', 'Wrist', 'Elbow', 'Hip', 'Back', 'Neck']
    pain_levels = list(range(1, 11))
    pain_locations = ['Joint', 'Muscle', 'Tendon', 'Ligament', 'Other']
    previous_injuries = ['ACL tear', 'Meniscus tear', 'Rotator cuff injury', 'Ankle sprain', 
                         'Tendonitis', 'Fracture', 'Dislocation', 'Muscle strain', 'None']
    surgical_histories = ['ACL reconstruction', 'Meniscus repair', 'Rotator cuff repair', 
                         'Joint replacement', 'None']
    goals = ['Pain reduction', 'Improve range of motion', 'Increase strength', 
             'Return to sports', 'Post-surgery recovery']
    
    difficulty_levels = ['beginner', 'intermediate', 'advanced']
    sets_options = [2, 3, 4]
    reps_options = [8, 10, 12, 15]
    
    data = []
    
    # Generate sample data
    for _ in range(200):
        body_part = np.random.choice(body_parts)
        pain_level = np.random.choice(pain_levels)
        pain_location = np.random.choice(pain_locations)
        previous_injury = np.random.choice(previous_injuries)
        surgical_history = np.random.choice(surgical_histories)
        goal = np.random.choice(goals)
        
        # Determine difficulty level based on pain level and other factors
        if pain_level > 7:
            difficulty = 'beginner'
        elif pain_level > 4:
            difficulty = 'intermediate'
        else:
            difficulty = 'advanced'
            
        # Determine sets and reps based on difficulty
        if difficulty == 'beginner':
            sets = 2
            reps = np.random.choice([8, 10])
        elif difficulty == 'intermediate':
            sets = 3
            reps = np.random.choice([10, 12])
        else:
            sets = 4
            reps = np.random.choice([12, 15])
            
        # Add some randomness
        if np.random.random() < 0.2:
            difficulty = np.random.choice(difficulty_levels)
            sets = np.random.choice(sets_options)
            reps = np.random.choice(reps_options)
        
        data.append({
            'body_part': body_part,
            'pain_level': pain_level,
            'pain_location': pain_location,
            'previous_injuries': previous_injury,
            'surgical_history': surgical_history,
            'primary_goal': goal,
            'difficulty_level': difficulty,
            'sets': sets,
            'reps': reps
        })
    
    return pd.DataFrame(data)

# Train and save the models
def train_models():
    print("Training models...")
    
    # Generate sample data
    df = generate_sample_data()
    
    # Prepare features and targets
    X = df[['body_part', 'pain_level', 'pain_location', 'previous_injuries', 
            'surgical_history', 'primary_goal']]
    y_difficulty = df['difficulty_level']
    y_sets = df['sets']
    y_reps = df['reps']
    
    # Encode categorical features
    categorical_features = ['body_part', 'pain_location', 'previous_injuries', 
                           'surgical_history', 'primary_goal']
    encoder = OneHotEncoder(sparse_output=False, handle_unknown='ignore')
    X_cat = pd.DataFrame(
        encoder.fit_transform(X[categorical_features]),
        columns=encoder.get_feature_names_out(categorical_features)
    )
    
    # Combine with numerical features
    X_num = X[['pain_level']].reset_index(drop=True)
    X_processed = pd.concat([X_num, X_cat], axis=1)
    
    # Train models
    # Decision Tree for difficulty level (categorical)
    dt_diff = DecisionTreeClassifier(max_depth=5, random_state=42)
    dt_diff.fit(X_processed, y_difficulty)
    
    # Random Forest for sets and reps (numerical)
    rf_sets = RandomForestClassifier(n_estimators=50, random_state=42)
    rf_sets.fit(X_processed, y_sets)
    
    rf_reps = RandomForestClassifier(n_estimators=50, random_state=42)
    rf_reps.fit(X_processed, y_reps)
    
    # Clean up and recreate models directory to ensure fresh models
    if os.path.exists('models'):
        shutil.rmtree('models')
    os.makedirs('models')
    
    # Save models and encoder
    try:
        joblib.dump(dt_diff, 'models/difficulty_model.pkl')
        joblib.dump(rf_sets, 'models/sets_model.pkl')
        joblib.dump(rf_reps, 'models/reps_model.pkl')
        joblib.dump(encoder, 'models/feature_encoder.pkl')
        print("Models saved successfully.")
    except Exception as e:
        print(f"Error saving models: {e}")
        raise
    
    return encoder, dt_diff, rf_sets, rf_reps

# Load or train models
def get_models():
    try:
        # Try to load all models
        encoder = joblib.load('models/feature_encoder.pkl')
        dt_diff = joblib.load('models/difficulty_model.pkl')
        rf_sets = joblib.load('models/sets_model.pkl')
        rf_reps = joblib.load('models/reps_model.pkl')
        print("Models loaded successfully.")
        return encoder, dt_diff, rf_sets, rf_reps
    except (FileNotFoundError, EOFError, Exception) as e:
        # If any error occurs during loading, retrain all models
        print(f"Error loading models: {e}. Training new models...")
        return train_models()

# Exercise database
def get_exercise_database():
    """
    Database of exercises for different body parts
    """
    exercises = {
        'knee': [
            {
                'name': 'Straight Leg Raises',
                'description': 'Lie flat on your back with one leg bent and the other straight. Tighten the thigh muscle of the straight leg and slowly raise it to the height of the bent knee.',
                'bodyPart': 'Knee',
                'durationSeconds': 30,
            },
            {
                'name': 'Hamstring Curls',
                'description': 'Stand facing a wall or sturdy object for balance. Bend your affected knee, bringing your heel toward your buttocks. Hold, then lower slowly.',
                'bodyPart': 'Knee',
                'durationSeconds': 45,
            },
            {
                'name': 'Wall Squats',
                'description': 'Stand with your back against a wall, feet shoulder-width apart. Slide down the wall until your knees are bent at about 45 degrees. Hold, then slide back up.',
                'bodyPart': 'Knee',
                'durationSeconds': 60,
            },
            {
                'name': 'Step-Ups',
                'description': 'Step up onto a platform with your affected leg, then step down. Repeat.',
                'bodyPart': 'Knee',
                'durationSeconds': 45,
            },
            {
                'name': 'Knee Extensions',
                'description': 'Sit in a chair and extend your affected leg until straight, then lower slowly.',
                'bodyPart': 'Knee',
                'durationSeconds': 30,
            }
        ],
        'shoulder': [
            {
                'name': 'Pendulum Exercise',
                'description': 'Lean forward slightly with support, allowing your affected arm to hang down. Swing your arm gently in small circles, then in larger circles. Repeat in the opposite direction.',
                'bodyPart': 'Shoulder',
                'durationSeconds': 30,
            },
            {
                'name': 'Wall Crawl',
                'description': 'Stand facing a wall with your affected arm. Walk your fingers up the wall as high as comfortable. Slowly lower back down.',
                'bodyPart': 'Shoulder',
                'durationSeconds': 45,
            },
            {
                'name': 'External Rotation',
                'description': 'Holding a light resistance band, keep your elbow at 90 degrees and close to your side. Rotate your forearm outward, away from your body.',
                'bodyPart': 'Shoulder',
                'durationSeconds': 60,
            },
            {
                'name': 'Internal Rotation',
                'description': 'With your elbow at your side, rotate your arm inward against resistance.',
                'bodyPart': 'Shoulder',
                'durationSeconds': 45,
            },
            {
                'name': 'Shoulder Flexion',
                'description': 'Raise your arm forward and upward as high as comfortable.',
                'bodyPart': 'Shoulder',
                'durationSeconds': 30,
            }
        ],
        'ankle': [
            {
                'name': 'Ankle Pumps',
                'description': 'Move your foot up and down, bending at the ankle. This improves circulation and range of motion.',
                'bodyPart': 'Ankle',
                'durationSeconds': 30,
            },
            {
                'name': 'Ankle Circles',
                'description': 'Rotate your ankle clockwise and counterclockwise, making circles with your toes.',
                'bodyPart': 'Ankle',
                'durationSeconds': 45,
            },
            {
                'name': 'Heel Raises',
                'description': 'Stand with feet shoulder-width apart. Raise up onto your toes, then lower back down.',
                'bodyPart': 'Ankle',
                'durationSeconds': 60,
            },
            {
                'name': 'Resistance Band Eversion',
                'description': 'With a resistance band, turn your foot outward against the resistance.',
                'bodyPart': 'Ankle',
                'durationSeconds': 45,
            },
            {
                'name': 'Resistance Band Inversion',
                'description': 'With a resistance band, turn your foot inward against the resistance.',
                'bodyPart': 'Ankle',
                'durationSeconds': 45,
            }
        ],
        'wrist': [
            {
                'name': 'Wrist Flexion and Extension',
                'description': 'Hold your arm out with palm facing down. Bend your wrist down, then up.',
                'bodyPart': 'Wrist',
                'durationSeconds': 30,
            },
            {
                'name': 'Wrist Rotations',
                'description': 'Rotate your wrist in circles, clockwise and counterclockwise.',
                'bodyPart': 'Wrist',
                'durationSeconds': 45,
            },
            {
                'name': 'Finger Stretches',
                'description': 'Spread your fingers wide, then make a fist. Repeat.',
                'bodyPart': 'Wrist',
                'durationSeconds': 60,
            },
            {
                'name': 'Grip Strengthening',
                'description': 'Squeeze a soft ball or stress ball, hold, then release.',
                'bodyPart': 'Wrist',
                'durationSeconds': 45,
            },
            {
                'name': 'Wrist Stretches',
                'description': 'Extend your arm with palm up, use your other hand to gently pull fingers back toward your body.',
                'bodyPart': 'Wrist',
                'durationSeconds': 30,
            }
        ],
        'elbow': [
            {
                'name': 'Elbow Flexion and Extension',
                'description': 'Bend and straighten your elbow slowly.',
                'bodyPart': 'Elbow',
                'durationSeconds': 30,
            },
            {
                'name': 'Wrist Turns',
                'description': 'With elbow bent at 90 degrees, rotate your palm up and down.',
                'bodyPart': 'Elbow',
                'durationSeconds': 45,
            },
            {
                'name': 'Bicep Curls',
                'description': 'Hold a light weight and bend your elbow to bring your hand toward your shoulder.',
                'bodyPart': 'Elbow',
                'durationSeconds': 60,
            },
            {
                'name': 'Tricep Extensions',
                'description': 'Hold a light weight behind your head and extend your arm upward.',
                'bodyPart': 'Elbow',
                'durationSeconds': 45,
            },
            {
                'name': 'Elbow Stretches',
                'description': 'Extend your arm and gently pull your hand toward your opposite shoulder.',
                'bodyPart': 'Elbow',
                'durationSeconds': 30,
            }
        ],
        'hip': [
            {
                'name': 'Hip Abduction',
                'description': 'Lie on your side and lift your top leg upward, away from your other leg.',
                'bodyPart': 'Hip',
                'durationSeconds': 30,
            },
            {
                'name': 'Hip Flexion',
                'description': 'Standing, lift your knee toward your chest.',
                'bodyPart': 'Hip',
                'durationSeconds': 45,
            },
            {
                'name': 'Hip Extensions',
                'description': 'Standing, extend one leg behind you, keeping it straight.',
                'bodyPart': 'Hip',
                'durationSeconds': 60,
            },
            {
                'name': 'Bridges',
                'description': 'Lie on your back with knees bent. Lift your hips forming a bridge.',
                'bodyPart': 'Hip',
                'durationSeconds': 45,
            },
            {
                'name': 'Clamshells',
                'description': 'Lie on your side with knees bent. Open your top knee like a clamshell while keeping feet together.',
                'bodyPart': 'Hip',
                'durationSeconds': 30,
            }
        ],
        'back': [
            {
                'name': 'Prone Press-ups',
                'description': 'Lie face down and press up with your hands, keeping your hips on the ground.',
                'bodyPart': 'Back',
                'durationSeconds': 30,
            },
            {
                'name': 'Bridges',
                'description': 'Lie on your back with knees bent. Lift your hips forming a bridge.',
                'bodyPart': 'Back',
                'durationSeconds': 45,
            },
            {
                'name': 'Cat-Camel Stretch',
                'description': 'On hands and knees, alternate between arching and rounding your back.',
                'bodyPart': 'Back',
                'durationSeconds': 60,
            },
            {
                'name': 'Bird Dog',
                'description': 'On hands and knees, extend opposite arm and leg simultaneously.',
                'bodyPart': 'Back',
                'durationSeconds': 45,
            },
            {
                'name': 'Pelvic Tilts',
                'description': 'Lie on your back with knees bent. Tilt your pelvis by flattening your back against the floor.',
                'bodyPart': 'Back',
                'durationSeconds': 30,
            }
        ],
        'neck': [
            {
                'name': 'Neck Rotation',
                'description': 'Slowly turn your head to look over each shoulder.',
                'bodyPart': 'Neck',
                'durationSeconds': 30,
            },
            {
                'name': 'Chin Tucks',
                'description': 'Pull your chin straight back, creating a "double chin."',
                'bodyPart': 'Neck',
                'durationSeconds': 45,
            },
            {
                'name': 'Side Bend Stretch',
                'description': 'Gently tilt your head toward each shoulder.',
                'bodyPart': 'Neck',
                'durationSeconds': 60,
            },
            {
                'name': 'Neck Flexion and Extension',
                'description': 'Gently nod your head forward and back.',
                'bodyPart': 'Neck',
                'durationSeconds': 45,
            },
            {
                'name': 'Isometric Exercises',
                'description': 'Place your hand against your head and push gently, resisting with your neck muscles.',
                'bodyPart': 'Neck',
                'durationSeconds': 30,
            }
        ],
        'default': [
            {
                'name': 'Range of Motion Exercise',
                'description': 'Gently move the affected body part through its full range of motion, stopping when you feel pain or discomfort.',
                'bodyPart': 'General',
                'durationSeconds': 30,
            },
            {
                'name': 'Strengthening Exercise',
                'description': 'Using light resistance, perform targeted strengthening movements for the affected area.',
                'bodyPart': 'General',
                'durationSeconds': 45,
            },
            {
                'name': 'Stability Exercise',
                'description': 'Focus on maintaining balance and stability while engaging the affected area.',
                'bodyPart': 'General',
                'durationSeconds': 60,
            }
        ]
    }
    
    return exercises

# Generate a rehabilitation plan based on user data
def generate_plan(rehab_data):
    """
    Generate a personalized rehabilitation plan based on user data
    """
    try:
        # Load models
        encoder, dt_diff, rf_sets, rf_reps = get_models()
        
        # Extract data
        medical_history = rehab_data.get('medicalHistory', {})
        physical_condition = rehab_data.get('physicalCondition', {})
        goals = rehab_data.get('rehabilitationGoals', [])
        
        body_part = physical_condition.get('bodyPart', 'Knee')
        pain_level = physical_condition.get('painLevel', 5)
        pain_location = physical_condition.get('painLocation', 'Joint')
        previous_injuries = medical_history.get('previousInjuries', 'None')
        surgical_history = medical_history.get('surgicalHistory', 'None')
        primary_goal = goals[0] if goals else 'Pain reduction'
        
        # Prepare input data for prediction
        input_data = pd.DataFrame([{
            'body_part': body_part,
            'pain_level': int(pain_level),
            'pain_location': pain_location,
            'previous_injuries': previous_injuries,
            'surgical_history': surgical_history,
            'primary_goal': primary_goal
        }])
        
        # Encode categorical features
        categorical_features = ['body_part', 'pain_location', 'previous_injuries', 
                               'surgical_history', 'primary_goal']
        X_cat = pd.DataFrame(
            encoder.transform(input_data[categorical_features]),
            columns=encoder.get_feature_names_out(categorical_features)
        )
        
        # Combine with numerical features
        X_num = input_data[['pain_level']].reset_index(drop=True)
        X_processed = pd.concat([X_num, X_cat], axis=1)
        
        # Make predictions
        difficulty = dt_diff.predict(X_processed)[0]
        sets = rf_sets.predict(X_processed)[0]
        reps = rf_reps.predict(X_processed)[0]
        
        # Get exercises from database
        exercise_db = get_exercise_database()
        body_part_key = body_part.lower()
        if body_part_key in exercise_db:
            exercises_list = exercise_db[body_part_key]
        else:
            exercises_list = exercise_db['default']
        
        # Create exercises with predicted parameters
        exercises = []
        for i, ex in enumerate(exercises_list):
            exercise_id = f"{body_part.lower()}_{i+1}_{uuid.uuid4().hex[:4]}"
            exercise = {
                'id': exercise_id,
                'name': ex['name'],
                'description': ex['description'],
                'bodyPart': ex['bodyPart'],
                'sets': int(sets),
                'reps': int(reps),
                'durationSeconds': int(ex['durationSeconds']),
                'difficultyLevel': str(difficulty)
            }
            exercises.append(exercise)
        
        # Create plan title and description
        title = f"{body_part} Rehabilitation Plan"
        description = f"A personalized plan for {body_part} recovery"
        if goals:
            description += f" focusing on {', '.join(goals)}."
        
        # Create the rehabilitation plan
        plan = {
            'title': title,
            'description': description,
            'exercises': exercises,
            'goals': {
                'primary': primary_goal,
                'bodyPart': body_part,
                'painReduction': 'high' if pain_level > 7 else ('medium' if pain_level > 4 else 'low'),
            }
        }
        
        return plan
    
    except Exception as e:
        print(f"Error generating plan: {e}")
        raise

# API routes
@app.route('/api/generate_plan', methods=['POST'])
def api_generate_plan():
    try:
        print("Received request")
        print(request.json) 
        rehab_data = request.json
        plan = generate_plan(rehab_data)
        return jsonify(plan)
    except Exception as e:
        print(f"Error in /generate_plan: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/health', methods=['GET'])
def health_check():
    return jsonify({'status': 'ok'})

# Initialize models on startup
def initialize():
    try:
        get_models()
        print("Models initialized successfully")
    except Exception as e:
        print(f"Error initializing models: {e}")

# Initialize on startup
with app.app_context():
    initialize()

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')