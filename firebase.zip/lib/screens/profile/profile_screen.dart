import 'package:flutter/material.dart';
import 'package:personalized_rehabilitation_plans/screens/auth/login_screen.dart';
import 'package:provider/provider.dart';

import '../../services/auth_service.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  bool _isTherapist = false;
  bool _isLoading = false;

  late AuthService authService;

  Future<void> _saveData() async {
    try {
      if (!_formKey.currentState!.validate()) return;

      setState(() {
        _isLoading = true;
      });

      authService.currentUserModel!.name = _nameController.text.trim();
      authService.currentUserModel!.isTherapist = _isTherapist;

      await authService.updateUserData(authService.currentUserModel!);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(e.toString()),
            backgroundColor: Colors.red,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  void signOut() async {
    try {
      await authService.signOut();

      Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(
            builder: (context) => const LoginScreen(),
          ),
          (_) => false);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(e.toString()),
        ),
      );
    }
  }

  @override
  void initState() {
    authService = Provider.of<AuthService>(context, listen: false);
    _nameController.text = authService.currentUserModel!.name;
    _emailController.text = authService.currentUserModel!.email;
    _isTherapist = authService.currentUserModel!.isTherapist;
    setState(() {});

    super.initState();
  }

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile'),
        elevation: 0,
        backgroundColor: Colors.transparent,
        foregroundColor: Theme.of(context).primaryColor,
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(25),
        child: SizedBox(
          height: 50,
          width: MediaQuery.sizeOf(context).width * 0.8,
          child: ElevatedButton(
            onPressed: () => signOut(),
            child: const Text(
              'Log out',
              style: TextStyle(fontSize: 16),
            ),
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              const CircleAvatar(
                radius: 50,
                backgroundImage: NetworkImage(
                    'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png'),
              ),
              const SizedBox(height: 24),
              textField('Full Name', _nameController, Icons.person_outline),
              const SizedBox(height: 16),
              textField('Email', _emailController, Icons.email_outlined,
                  readOnly: true),
              const SizedBox(height: 16),
              SwitchListTile(
                title: const Text('I am a therapist'),
                subtitle: const Text(
                    'You are signed up as a healthcare professional'),
                value: _isTherapist,
                activeColor: Theme.of(context).primaryColor,
                onChanged: (bool value) {
                  setState(() {
                    _isTherapist = value;
                  });
                },
              ),
              const SizedBox(height: 32),
              SizedBox(
                height: 50,
                width: MediaQuery.sizeOf(context).width * 0.8,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : _saveData,
                  child: _isLoading
                      ? const CircularProgressIndicator(
                          valueColor:
                              AlwaysStoppedAnimation<Color>(Colors.white),
                        )
                      : const Text(
                          'Save',
                          style: TextStyle(fontSize: 16),
                        ),
                ),
              ),
              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }

  Widget textField(
      String title, TextEditingController controller, IconData prefixIcon,
      {bool readOnly = false}) {
    return TextFormField(
      controller: controller,
      readOnly: readOnly,
      keyboardType: TextInputType.name,
      decoration: InputDecoration(
        labelText: title,
        prefixIcon: Icon(prefixIcon),
      ),
      validator: (value) {
        if (value == null || value.isEmpty) {
          return 'Please enter your name';
        }
        return null;
      },
    );
  }
}
