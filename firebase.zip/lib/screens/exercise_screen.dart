import 'package:circular_countdown_timer/circular_countdown_timer.dart';
import 'package:flutter/material.dart';
import 'package:personalized_rehabilitation_plans/widgets/custom_button.dart';
import '../models/rehabilitation_models.dart';

class ExerciseScreen extends StatefulWidget {
  const ExerciseScreen({super.key, required this.exercise});

  final Exercise exercise;

  @override
  State<ExerciseScreen> createState() => _ExerciseScreenState();
}

class _ExerciseScreenState extends State<ExerciseScreen> {
  final CountDownController _controller = CountDownController();
  bool _hasStarted = false;

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.sizeOf(context);
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.exercise.name),
        elevation: 0,
        backgroundColor: Colors.transparent,
        foregroundColor: Theme.of(context).primaryColor,
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(20),
        child: CustomButton(
          text: 'Complete Exercise',
          onPressed: () {
            Navigator.pop(context, true);
          },
        ),
      ),
      body: SafeArea(
          child: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Instructions:',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              widget.exercise.description,
              style: const TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 16),
            const Text(
              'Details:',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: _buildDetailItem(
                    'Sets',
                    widget.exercise.sets.toString(),
                    Icons.repeat,
                  ),
                ),
                Expanded(
                  child: _buildDetailItem(
                    'Reps',
                    widget.exercise.reps.toString(),
                    Icons.fitness_center,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: _buildDetailItem(
                    'Duration',
                    '${widget.exercise.durationSeconds} sec',
                    Icons.timer,
                  ),
                ),
                Expanded(
                  child: _buildDetailItem(
                    'Body Part',
                    widget.exercise.bodyPart,
                    Icons.accessibility_new,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 40),
            Center(
              child: CircularCountDownTimer(
                controller: _controller,
                width: size.width * 0.4,
                height: size.width * 0.4,
                duration: widget.exercise.durationSeconds,
                fillColor: const Color(0xFF1E88E5).withOpacity(0.6),
                backgroundColor: const Color(0xFF1E88E5),
                ringColor: Colors.grey.shade400,
                strokeWidth: 8,
                isReverse: true,
                isReverseAnimation: true,
                autoStart: false,
                textStyle: const TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    color: Colors.white),
              ),
            ),
            const SizedBox(height: 16),
            Center(
              child: CustomButton(
                text: _hasStarted ? 'Restart' : 'Start',
                width: 120,
                onPressed: () {
                  setState(() {
                    _hasStarted = true;
                  });
                  _controller.restart(
                      duration: widget.exercise.durationSeconds);
                },
              ),
            ),
          ],
        ),
      )),
    );
  }

  Widget _buildDetailItem(String label, String value, IconData icon) {
    return Row(
      children: [
        Icon(
          icon,
          size: 24,
          color: Colors.grey[600],
        ),
        const SizedBox(width: 8),
        Expanded(
          child: RichText(
            text: TextSpan(
              style: const TextStyle(color: Colors.black87),
              children: [
                TextSpan(
                  text: '$label: ',
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 18,
                  ),
                ),
                TextSpan(
                  text: value,
                  style: TextStyle(
                    color: Colors.grey[700],
                    fontSize: 18,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
