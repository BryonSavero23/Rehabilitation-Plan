import 'package:flutter/material.dart';
import 'package:personalized_rehabilitation_plans/models/rehabilitation_models.dart';
import 'package:personalized_rehabilitation_plans/screens/exercise_recommendation_screen.dart';
import 'package:personalized_rehabilitation_plans/services/rehabilitation_service.dart';
import 'package:personalized_rehabilitation_plans/widgets/enhanced_dropdown.dart';

class UserInputScreen extends StatefulWidget {
  const UserInputScreen({Key? key}) : super(key: key);

  @override
  State<UserInputScreen> createState() => _UserInputScreenState();
}

class _UserInputScreenState extends State<UserInputScreen> {
  final _formKey = GlobalKey<FormState>();

  // Medical History Fields
  String _selectedPreviousInjury = 'None';
  String _otherPreviousInjury = '';
  String _selectedSurgicalHistory = 'None';
  String _otherSurgicalHistory = '';

  // Physical Condition Fields
  String _selectedBodyPart = 'Knee';
  String _otherBodyPart = '';
  final _painLevelController = TextEditingController(text: '5');
  String _selectedPainLocation = 'Joint';
  String _otherPainLocation = '';

  // Rehabilitation Goals
  final List<String> _selectedGoals = [];
  final _otherGoalController = TextEditingController();

  bool _isLoading = false;
  int _currentStep = 0;

  // Dropdown options
  final List<String> _previousInjuries = [
    'None',
    'Sprain',
    'Strain',
    'Fracture',
    'Dislocation',
    'Tear (Ligament/Muscle)',
    'Tendonitis',
    'Bursitis',
    'Arthritis',
    'Other',
  ];

  final List<String> _surgicalHistories = [
    'None',
    'ACL Reconstruction',
    'Meniscus Repair',
    'Rotator Cuff Repair',
    'Shoulder Arthroscopy',
    'Hip Replacement',
    'Knee Replacement',
    'Spinal Fusion',
    'Carpal Tunnel Release',
    'Other',
  ];

  final List<String> _bodyParts = [
    'Knee',
    'Shoulder',
    'Ankle',
    'Wrist',
    'Elbow',
    'Hip',
    'Back',
    'Neck',
  ];

  final List<String> _painLocations = [
    'Joint',
    'Muscle',
    'Tendon',
    'Ligament',
  ];

  final List<String> _rehabilitationGoals = [
    'Pain reduction',
    'Improve range of motion',
    'Increase strength',
    'Return to sports',
    'Improve daily function',
    'Prevent re-injury',
    'Post-surgery recovery',
  ];

  @override
  void dispose() {
    _painLevelController.dispose();
    _otherGoalController.dispose();
    super.dispose();
  }

  Widget _buildMedicalHistoryForm() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Please provide information about your medical history to help us create a personalized rehabilitation plan.',
          style: Theme.of(context).textTheme.bodyMedium,
        ),
        const SizedBox(height: 20),

        // Previous Injuries Dropdown
        EnhancedDropdown(
          label: 'Previous Injuries',
          items: _previousInjuries,
          value: _selectedPreviousInjury,
          onChanged: (value) {
            setState(() {
              _selectedPreviousInjury = value;
            });
          },
          otherValue: _otherPreviousInjury,
          onOtherChanged: (value) {
            setState(() {
              _otherPreviousInjury = value;
            });
          },
          otherHintText: 'Describe your injury',
        ),
        const SizedBox(height: 16),

        // Surgical History Dropdown
        EnhancedDropdown(
          label: 'Surgical History',
          items: _surgicalHistories,
          value: _selectedSurgicalHistory,
          onChanged: (value) {
            setState(() {
              _selectedSurgicalHistory = value;
            });
          },
          otherValue: _otherSurgicalHistory,
          onOtherChanged: (value) {
            setState(() {
              _otherSurgicalHistory = value;
            });
          },
          otherHintText: 'Describe your surgery',
        ),
      ],
    );
  }

  Widget _buildPhysicalConditionForm() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Tell us about your current physical condition and limitations.',
          style: Theme.of(context).textTheme.bodyMedium,
        ),
        const SizedBox(height: 20),

        // Body Part with Enhanced Dropdown
        EnhancedDropdown(
          label: 'Affected Body Part',
          items: _bodyParts,
          value: _selectedBodyPart,
          onChanged: (value) {
            setState(() {
              _selectedBodyPart = value;
            });
          },
          otherValue: _otherBodyPart,
          onOtherChanged: (value) {
            setState(() {
              _otherBodyPart = value;
            });
          },
          otherHintText: 'Specify the affected body part',
          isRequired: true,
        ),
        const SizedBox(height: 16),

        // Pain Level
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Pain Level (0-10)',
              style: TextStyle(
                fontSize: 16,
                color: Colors.grey[700],
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                const Text('0'),
                Expanded(
                  child: Slider(
                    value: double.tryParse(_painLevelController.text) ?? 5,
                    min: 0,
                    max: 10,
                    divisions: 10,
                    label: _painLevelController.text,
                    onChanged: (value) {
                      setState(() {
                        _painLevelController.text = value.toInt().toString();
                      });
                    },
                  ),
                ),
                const Text('10'),
              ],
            ),
            Center(
              child: Text(
                _getPainLevelDescription(
                    int.tryParse(_painLevelController.text) ?? 5),
                style: TextStyle(
                  color: _getPainLevelColor(
                      int.tryParse(_painLevelController.text) ?? 5),
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),

        // Pain Location with Enhanced Dropdown
        EnhancedDropdown(
          label: 'Pain Location',
          items: _painLocations,
          value: _selectedPainLocation,
          onChanged: (value) {
            setState(() {
              _selectedPainLocation = value;
            });
          },
          otherValue: _otherPainLocation,
          onOtherChanged: (value) {
            setState(() {
              _otherPainLocation = value;
            });
          },
          otherHintText: 'Specify the pain location',
        ),
      ],
    );
  }

  Widget _buildRehabilitationGoalsForm() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'What goals do you want to achieve through rehabilitation?',
          style: Theme.of(context).textTheme.bodyMedium,
        ),
        const SizedBox(height: 20),

        // Rehabilitation Goals Checkboxes
        ...List.generate(_rehabilitationGoals.length, (index) {
          final goal = _rehabilitationGoals[index];
          return CheckboxListTile(
            title: Text(goal),
            value: _selectedGoals.contains(goal),
            onChanged: (selected) {
              setState(() {
                if (selected == true) {
                  if (!_selectedGoals.contains(goal)) {
                    _selectedGoals.add(goal);
                  }
                } else {
                  _selectedGoals.remove(goal);
                }
              });
            },
            activeColor: Theme.of(context).primaryColor,
            controlAffinity: ListTileControlAffinity.leading,
            contentPadding: EdgeInsets.zero,
          );
        }),

        // "Other" option for goals
        CheckboxListTile(
          title: const Text('Other'),
          value: _selectedGoals.contains('Other'),
          onChanged: (selected) {
            setState(() {
              if (selected == true) {
                if (!_selectedGoals.contains('Other')) {
                  _selectedGoals.add('Other');
                }
              } else {
                _selectedGoals.remove('Other');
              }
            });
          },
          activeColor: Theme.of(context).primaryColor,
          controlAffinity: ListTileControlAffinity.leading,
          contentPadding: EdgeInsets.zero,
        ),

        // Other Goal Text Field (shown only if 'Other' is selected)
        if (_selectedGoals.contains('Other'))
          Padding(
            padding: const EdgeInsets.only(top: 8.0, left: 32.0),
            child: TextFormField(
              controller: _otherGoalController,
              decoration: const InputDecoration(
                labelText: 'Specify Other Goal',
                hintText: 'Enter your goal',
              ),
              validator: (value) {
                if (_selectedGoals.contains('Other') &&
                    (value == null || value.isEmpty)) {
                  return 'Please specify your other goal';
                }
                return null;
              },
            ),
          ),

        const SizedBox(height: 20),
        Text(
          'Note: This information will be used to create your personalized rehabilitation plan.',
          style: TextStyle(
            color: Colors.grey[600],
            fontStyle: FontStyle.italic,
            fontSize: 12,
          ),
        ),
      ],
    );
  }

  String _getPainLevelDescription(int level) {
    if (level <= 2) {
      return 'Mild pain';
    } else if (level <= 5) {
      return 'Moderate pain';
    } else if (level <= 7) {
      return 'Severe pain';
    } else {
      return 'Very severe pain';
    }
  }

  Color _getPainLevelColor(int level) {
    if (level <= 2) {
      return Colors.green;
    } else if (level <= 5) {
      return Colors.orange;
    } else if (level <= 7) {
      return Colors.deepOrange;
    } else {
      return Colors.red;
    }
  }

  void _nextStep() {
    setState(() {
      _currentStep < 2 ? _currentStep += 1 : null;
    });
  }

  void _previousStep() {
    setState(() {
      _currentStep > 0 ? _currentStep -= 1 : null;
    });
  }

  StepState _getStepState(int step) {
    if (_currentStep > step) {
      return StepState.complete;
    } else if (_currentStep == step) {
      return StepState.editing;
    } else {
      return StepState.indexed;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Create Your Rehab Plan'),
        elevation: 0,
        backgroundColor: Colors.transparent,
        foregroundColor: Theme.of(context).primaryColor,
      ),
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: Stepper(
            type: StepperType.vertical,
            currentStep: _currentStep,
            onStepContinue: () {
              if (_currentStep < 2) {
                _nextStep();
              } else {
                _generateRehabilitationPlan();
              }
            },
            onStepCancel: _previousStep,
            controlsBuilder: (context, details) {
              return Padding(
                padding: const EdgeInsets.only(top: 20.0),
                child: Row(
                  children: [
                    Expanded(
                      child: ElevatedButton(
                        onPressed: _isLoading ? null : details.onStepContinue,
                        child: _isLoading && _currentStep == 2
                            ? const SizedBox(
                                height: 20,
                                width: 20,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  valueColor: AlwaysStoppedAnimation<Color>(
                                      Colors.white),
                                ),
                              )
                            : Text(_currentStep < 2
                                ? 'Continue'
                                : 'Generate Plan'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    if (_currentStep > 0)
                      Expanded(
                        child: OutlinedButton(
                          onPressed: details.onStepCancel,
                          child: const Text('Back'),
                        ),
                      ),
                  ],
                ),
              );
            },
            steps: [
              // Step 1: Medical History
              Step(
                title: const Text('Medical History'),
                subtitle:
                    const Text('Previous injuries and medical conditions'),
                content: _buildMedicalHistoryForm(),
                isActive: _currentStep >= 0,
                state: _getStepState(0),
              ),

              // Step 2: Physical Condition
              Step(
                title: const Text('Physical Condition'),
                subtitle: const Text('Current condition and limitations'),
                content: _buildPhysicalConditionForm(),
                isActive: _currentStep >= 1,
                state: _getStepState(1),
              ),

              // Step 3: Rehabilitation Goals
              Step(
                title: const Text('Rehabilitation Goals'),
                subtitle: const Text('What you want to achieve'),
                content: _buildRehabilitationGoalsForm(),
                isActive: _currentStep >= 2,
                state: _getStepState(2),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _generateRehabilitationPlan() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() {
      _isLoading = true;
    });

    try {
      // Prepare medical history data
      final String previousInjury = _selectedPreviousInjury == 'Other'
          ? _otherPreviousInjury
          : _selectedPreviousInjury;

      final String surgicalHistory = _selectedSurgicalHistory == 'Other'
          ? _otherSurgicalHistory
          : _selectedSurgicalHistory;

      final medicalHistory = {
        'previousInjuries': previousInjury,
        'surgicalHistory': surgicalHistory,
      };

      // Prepare physical condition data
      final String bodyPart =
          _selectedBodyPart == 'Other' ? _otherBodyPart : _selectedBodyPart;

      final String painLocation = _selectedPainLocation == 'Other'
          ? _otherPainLocation
          : _selectedPainLocation;

      final physicalCondition = {
        'bodyPart': bodyPart,
        'painLevel': int.tryParse(_painLevelController.text) ?? 5,
        'painLocation': painLocation,
      };

      // Prepare rehabilitation goals
      List<String> goals = List.from(_selectedGoals);
      if (_selectedGoals.contains('Other') &&
          _otherGoalController.text.isNotEmpty) {
        goals.remove('Other');
        goals.add(_otherGoalController.text.trim());
      }

      // Create rehabilitation data
      final rehabData = RehabilitationData(
        medicalHistory: medicalHistory,
        physicalCondition: physicalCondition,
        rehabilitationGoals: goals,
      );

      // Generate a plan
      final service = RehabilitationService();
      final plan = await service.generatePlan(rehabData);

      if (mounted) {
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => ExerciseRecommendationScreen(plan: plan),
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error generating plan: ${e.toString()}'),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }
}
