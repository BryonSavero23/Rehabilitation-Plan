import 'package:flutter/material.dart';
import 'package:personalized_rehabilitation_plans/screens/profile/profile_screen.dart';
import 'package:personalized_rehabilitation_plans/screens/user_input_screen.dart';
import 'package:personalized_rehabilitation_plans/screens/therapist/patient_management_dashboard.dart';
import 'package:provider/provider.dart';

import '../../services/auth_service.dart';
import '../saved_plans/saved_rehabilitation_plans.dart';

class BottomBarScreen extends StatefulWidget {
  const BottomBarScreen({super.key});

  @override
  State<BottomBarScreen> createState() => _BottomBarScreenState();
}

class _BottomBarScreenState extends State<BottomBarScreen> {
  int _selectedIndex = 0;
  bool _isTherapist = false;

  void _onItemTapped(int index) {
    setState(() => _selectedIndex = index);
  }

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final authService = Provider.of<AuthService>(context, listen: false);
      await authService.initializeUser();

      // Check if user is a therapist
      final isTherapist = await authService.isUserTherapist();
      if (mounted) {
        setState(() {
          _isTherapist = isTherapist;
        });
      }
    });

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Consumer<AuthService>(
        builder: (context, authService, child) {
          if (authService.isLoading) {
            return const Center(child: CircularProgressIndicator());
          }

          // Determine which screen to show based on selected index and user type
          if (_isTherapist) {
            // Therapist screens
            if (_selectedIndex == 0) {
              return const PatientManagementDashboard();
            } else if (_selectedIndex == 1) {
              return const SavedRehabilitationPlans();
            } else {
              return const ProfileScreen();
            }
          } else {
            // Patient screens
            if (_selectedIndex == 0) {
              return const UserInputScreen();
            } else if (_selectedIndex == 1) {
              return const SavedRehabilitationPlans();
            } else {
              return const ProfileScreen();
            }
          }
        },
      ),
      bottomNavigationBar:
          _isTherapist ? _buildTherapistBottomNav() : _buildPatientBottomNav(),
    );
  }

  // Bottom navigation for patient users
  Widget _buildPatientBottomNav() {
    return BottomNavigationBar(
      currentIndex: _selectedIndex,
      onTap: _onItemTapped,
      items: const [
        BottomNavigationBarItem(
          icon: Icon(Icons.home_filled),
          label: 'Home',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.bookmark),
          label: 'Saved Plans',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.person),
          label: 'Profile',
        ),
      ],
    );
  }

  // Bottom navigation for therapist users
  Widget _buildTherapistBottomNav() {
    return BottomNavigationBar(
      currentIndex: _selectedIndex,
      onTap: _onItemTapped,
      items: const [
        BottomNavigationBarItem(
          icon: Icon(Icons.people),
          label: 'Patients',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.healing),
          label: 'Plans',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.person),
          label: 'Profile',
        ),
      ],
    );
  }
}
