import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:personalized_rehabilitation_plans/services/auth_service.dart';
import 'package:personalized_rehabilitation_plans/widgets/custom_button.dart';
import 'package:personalized_rehabilitation_plans/screens/bottom_bar/bottom_bar.dart';

class TherapistRegistrationScreen extends StatefulWidget {
  final String userId;

  const TherapistRegistrationScreen({
    Key? key,
    required this.userId,
  }) : super(key: key);

  @override
  State<TherapistRegistrationScreen> createState() =>
      _TherapistRegistrationScreenState();
}

class _TherapistRegistrationScreenState
    extends State<TherapistRegistrationScreen> {
  final _formKey = GlobalKey<FormState>();
  final _licenseNumberController = TextEditingController();
  final _specialtyController = TextEditingController();
  final _yearsOfExperienceController = TextEditingController();
  final _educationController = TextEditingController();
  final _clinicNameController = TextEditingController();
  final _clinicAddressController = TextEditingController();
  String _selectedSpecialization = 'Physical Therapy';
  bool _isLoading = false;

  final List<String> _specializations = [
    'Physical Therapy',
    'Occupational Therapy',
    'Sports Medicine',
    'Orthopedic Rehabilitation',
    'Neurological Rehabilitation',
    'Pediatric Rehabilitation',
    'Geriatric Rehabilitation',
    'Other'
  ];

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final authService = Provider.of<AuthService>(context, listen: false);
      await authService.initializeUser();
    });
    super.initState();
  }

  @override
  void dispose() {
    _licenseNumberController.dispose();
    _specialtyController.dispose();
    _yearsOfExperienceController.dispose();
    _educationController.dispose();
    _clinicNameController.dispose();
    _clinicAddressController.dispose();
    super.dispose();
  }

  Future<void> _submitTherapistProfile() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() {
      _isLoading = true;
    });

    try {
      final authService = Provider.of<AuthService>(context, listen: false);

      // Prepare therapist profile data
      final therapistProfileData = {
        'licenseNumber': _licenseNumberController.text.trim(),
        'specialty': _specialtyController.text.trim(),
        'yearsOfExperience':
            int.tryParse(_yearsOfExperienceController.text.trim()) ?? 0,
        'education': _educationController.text.trim(),
        'clinicName': _clinicNameController.text.trim(),
        'clinicAddress': _clinicAddressController.text.trim(),
        'specialization': _selectedSpecialization,
        'isVerified': false, // Therapists start as unverified
        'verificationSubmittedDate': DateTime.now(),
      };

      // Save therapist profile data
      await authService.saveTherapistProfile(
          widget.userId, therapistProfileData);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
                'Therapist profile submitted successfully. Your account will be verified soon.'),
            backgroundColor: Colors.green,
          ),
        );

        // Navigate to main app
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const BottomBarScreen()),
          (route) => false,
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: ${e.toString()}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Therapist Registration'),
        elevation: 0,
        backgroundColor: Colors.transparent,
        foregroundColor: Theme.of(context).primaryColor,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Registration Info
                Text(
                  'Professional Information',
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.bold,
                        color: Theme.of(context).primaryColor,
                      ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Please provide your professional details to complete your therapist profile.',
                  style: TextStyle(
                    color: Colors.grey,
                    fontSize: 14,
                  ),
                ),
                const SizedBox(height: 24),

                // License Number
                TextFormField(
                  controller: _licenseNumberController,
                  decoration: const InputDecoration(
                    labelText: 'License Number',
                    hintText: 'Enter your professional license number',
                    prefixIcon: Icon(Icons.badge),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter your license number';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),

                // Specialization Dropdown
                DropdownButtonFormField<String>(
                  decoration: const InputDecoration(
                    labelText: 'Specialization',
                    prefixIcon: Icon(Icons.medical_services_outlined),
                  ),
                  value: _selectedSpecialization,
                  items: _specializations.map((specialization) {
                    return DropdownMenuItem(
                      value: specialization,
                      child: Text(specialization),
                    );
                  }).toList(),
                  onChanged: (value) {
                    if (value != null) {
                      setState(() {
                        _selectedSpecialization = value;
                      });
                    }
                  },
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please select your specialization';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),

                // Specialty/Focus Area
                TextFormField(
                  controller: _specialtyController,
                  decoration: const InputDecoration(
                    labelText: 'Specialty/Focus Area',
                    hintText:
                        'E.g., Sports injuries, Post-surgical rehabilitation',
                    prefixIcon: Icon(Icons.emoji_objects_outlined),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter your specialty';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),

                // Years of Experience
                TextFormField(
                  controller: _yearsOfExperienceController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'Years of Experience',
                    hintText: 'Enter number of years',
                    prefixIcon: Icon(Icons.timer_outlined),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter your years of experience';
                    }
                    if (int.tryParse(value) == null) {
                      return 'Please enter a valid number';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),

                // Education/Credentials
                TextFormField(
                  controller: _educationController,
                  decoration: const InputDecoration(
                    labelText: 'Education/Credentials',
                    hintText: 'E.g., DPT from University of Example',
                    prefixIcon: Icon(Icons.school_outlined),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter your education information';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 24),

                // Practice Information
                Text(
                  'Practice Information',
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.bold,
                        color: Theme.of(context).primaryColor,
                      ),
                ),
                const SizedBox(height: 16),

                // Clinic Name
                TextFormField(
                  controller: _clinicNameController,
                  decoration: const InputDecoration(
                    labelText: 'Clinic/Hospital Name',
                    hintText: 'Enter your place of practice',
                    prefixIcon: Icon(Icons.local_hospital_outlined),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter your clinic name';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),

                // Clinic Address
                TextFormField(
                  controller: _clinicAddressController,
                  decoration: const InputDecoration(
                    labelText: 'Clinic Address',
                    hintText: 'Enter your practice address',
                    prefixIcon: Icon(Icons.location_on_outlined),
                  ),
                  maxLines: 2,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter your clinic address';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 32),

                // Submit Button
                Center(
                  child: CustomButton(
                    text: 'Submit Registration',
                    onPressed: _submitTherapistProfile,
                    isLoading: _isLoading,
                    width: double.infinity,
                    icon: Icons.check_circle_outline,
                  ),
                ),

                const SizedBox(height: 16),

                // Note about verification
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.blue.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Colors.blue.withOpacity(0.3)),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.info_outline, color: Colors.blue),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          'Your therapist account will be reviewed for verification. You will be notified once your account is verified.',
                          style: TextStyle(
                            color: Colors.blue[800],
                            fontSize: 13,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
