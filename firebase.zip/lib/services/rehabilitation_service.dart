import 'dart:convert';
import 'dart:developer';
import 'package:http/http.dart' as http;
import 'package:personalized_rehabilitation_plans/models/rehabilitation_models.dart';

class RehabilitationService {
  // For now, we'll simulate the API calls with local data
  // In a real app, this would be a real API endpoint
  static const String baseUrl = 'http://10.213.70.77:5000/api';
// Flask local development server

  // Generate rehabilitation plan based on user data
  Future<RehabilitationPlan> generatePlan(RehabilitationData data) async {
    try {
      // In a real app, we would make an HTTP request to the backend
      // For now, we'll simulate the response

      final response = await http.post(
        Uri.parse('$baseUrl/generate_plan'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(data.toJson()),
      );

      log("Response: ${response.statusCode}");

      if (response.statusCode == 200) {
        return RehabilitationPlan.fromJson(jsonDecode(response.body));
      } else {
        throw Exception('Failed to generate plan: ${response.statusCode}');
      }

      // Simulate API call delay
      // await Future.delayed(const Duration(seconds: 2));

      // // Generate a sample plan based on the input data
      // return _generateSamplePlan(data);
    } catch (e) {
      log("Error: $e");
      throw Exception('Failed to generate plan: $e');
    }
  }

  // Generate a sample plan for demonstration purposes
  RehabilitationPlan _generateSamplePlan(RehabilitationData data) {
    final bodyPart = data.physicalCondition['bodyPart'] as String;
    final painLevel = data.physicalCondition['painLevel'] as int;
    final goals = data.rehabilitationGoals;

    // Determine difficulty level based on pain
    String difficultyLevel;
    if (painLevel > 7) {
      difficultyLevel = 'beginner';
    } else if (painLevel > 4) {
      difficultyLevel = 'intermediate';
    } else {
      difficultyLevel = 'advanced';
    }

    // Generate exercises based on body part
    final exercises =
        _generateExercisesForBodyPart(bodyPart, difficultyLevel, painLevel);

    // Create plan title and description
    String title = '$bodyPart Rehabilitation Plan';
    String description = 'A personalized plan for $bodyPart recovery';
    if (goals.isNotEmpty) {
      description += ' focusing on ${goals.join(', ')}.';
    }

    return RehabilitationPlan(
      title: title,
      description: description,
      exercises: exercises,
      goals: {
        'primary': goals.isNotEmpty ? goals.first : 'Pain reduction',
        'bodyPart': bodyPart,
        'painReduction':
            painLevel > 7 ? 'high' : (painLevel > 4 ? 'medium' : 'low'),
      },
    );
  }

  // Generate exercises for a specific body part
  List<Exercise> _generateExercisesForBodyPart(
      String bodyPart, String difficultyLevel, int painLevel) {
    List<Exercise> exercises = [];

    // Number of sets and reps based on difficulty and pain
    int sets = difficultyLevel == 'beginner'
        ? 2
        : (difficultyLevel == 'intermediate' ? 3 : 4);
    int reps = difficultyLevel == 'beginner'
        ? 10
        : (difficultyLevel == 'intermediate' ? 12 : 15);

    // Adjust for pain level
    if (painLevel > 7) {
      sets = sets > 1 ? sets - 1 : sets;
      reps = (reps * 0.8).round();
    }

    // Define exercises based on body part
    switch (bodyPart.toLowerCase()) {
      case 'knee':
        exercises = [
          Exercise(
            id: 'knee_1',
            name: 'Straight Leg Raises',
            description:
                'Lie flat on your back with one leg bent and the other straight. Tighten the thigh muscle of the straight leg and slowly raise it to the height of the bent knee.',
            bodyPart: 'Knee',
            sets: sets,
            reps: reps,
            durationSeconds: 30,
            difficultyLevel: difficultyLevel,
          ),
          Exercise(
            id: 'knee_2',
            name: 'Hamstring Curls',
            description:
                'Stand facing a wall or sturdy object for balance. Bend your affected knee, bringing your heel toward your buttocks. Hold, then lower slowly.',
            bodyPart: 'Knee',
            sets: sets,
            reps: reps,
            durationSeconds: 45,
            difficultyLevel: difficultyLevel,
          ),
          Exercise(
            id: 'knee_3',
            name: 'Wall Squats',
            description:
                'Stand with your back against a wall, feet shoulder-width apart. Slide down the wall until your knees are bent at about 45 degrees. Hold, then slide back up.',
            bodyPart: 'Knee',
            sets: sets,
            reps: reps - 2,
            durationSeconds: 60,
            difficultyLevel: difficultyLevel,
          ),
        ];
        break;

      case 'shoulder':
        exercises = [
          Exercise(
            id: 'shoulder_1',
            name: 'Pendulum Exercise',
            description:
                'Lean forward slightly with support, allowing your affected arm to hang down. Swing your arm gently in small circles, then in larger circles. Repeat in the opposite direction.',
            bodyPart: 'Shoulder',
            sets: sets,
            reps: reps,
            durationSeconds: 30,
            difficultyLevel: difficultyLevel,
          ),
          Exercise(
            id: 'shoulder_2',
            name: 'Wall Crawl',
            description:
                'Stand facing a wall with your affected arm. Walk your fingers up the wall as high as comfortable. Slowly lower back down.',
            bodyPart: 'Shoulder',
            sets: sets,
            reps: reps,
            durationSeconds: 45,
            difficultyLevel: difficultyLevel,
          ),
          Exercise(
            id: 'shoulder_3',
            name: 'External Rotation',
            description:
                'Holding a light resistance band, keep your elbow at 90 degrees and close to your side. Rotate your forearm outward, away from your body.',
            bodyPart: 'Shoulder',
            sets: sets,
            reps: reps,
            durationSeconds: 60,
            difficultyLevel: difficultyLevel,
          ),
        ];
        break;

      case 'ankle':
        exercises = [
          Exercise(
            id: 'ankle_1',
            name: 'Ankle Pumps',
            description:
                'Move your foot up and down, bending at the ankle. This improves circulation and range of motion.',
            bodyPart: 'Ankle',
            sets: sets,
            reps: reps,
            durationSeconds: 30,
            difficultyLevel: difficultyLevel,
          ),
          Exercise(
            id: 'ankle_2',
            name: 'Ankle Circles',
            description:
                'Rotate your ankle clockwise and counterclockwise, making circles with your toes.',
            bodyPart: 'Ankle',
            sets: sets,
            reps: reps,
            durationSeconds: 45,
            difficultyLevel: difficultyLevel,
          ),
          Exercise(
            id: 'ankle_3',
            name: 'Heel Raises',
            description:
                'Stand with feet shoulder-width apart. Raise up onto your toes, then lower back down.',
            bodyPart: 'Ankle',
            sets: sets,
            reps: reps,
            durationSeconds: 60,
            difficultyLevel: difficultyLevel,
          ),
        ];
        break;

      case 'wrist':
        exercises = [
          Exercise(
            id: 'wrist_1',
            name: 'Wrist Flexion and Extension',
            description:
                'Hold your arm out with palm facing down. Bend your wrist down, then up.',
            bodyPart: 'Wrist',
            sets: sets,
            reps: reps,
            durationSeconds: 30,
            difficultyLevel: difficultyLevel,
          ),
          Exercise(
            id: 'wrist_2',
            name: 'Wrist Rotations',
            description:
                'Rotate your wrist in circles, clockwise and counterclockwise.',
            bodyPart: 'Wrist',
            sets: sets,
            reps: reps,
            durationSeconds: 45,
            difficultyLevel: difficultyLevel,
          ),
          Exercise(
            id: 'wrist_3',
            name: 'Finger Stretches',
            description: 'Spread your fingers wide, then make a fist. Repeat.',
            bodyPart: 'Wrist',
            sets: sets,
            reps: reps,
            durationSeconds: 60,
            difficultyLevel: difficultyLevel,
          ),
        ];
        break;

      case 'elbow':
        exercises = [
          Exercise(
            id: 'elbow_1',
            name: 'Elbow Flexion and Extension',
            description: 'Bend and straighten your elbow slowly.',
            bodyPart: 'Elbow',
            sets: sets,
            reps: reps,
            durationSeconds: 30,
            difficultyLevel: difficultyLevel,
          ),
          Exercise(
            id: 'elbow_2',
            name: 'Wrist Turns (Forearm Pronation/Supination)',
            description:
                'With elbow bent at 90 degrees, rotate your palm up and down.',
            bodyPart: 'Elbow',
            sets: sets,
            reps: reps,
            durationSeconds: 45,
            difficultyLevel: difficultyLevel,
          ),
          Exercise(
            id: 'elbow_3',
            name: 'Bicep Curls',
            description:
                'Hold a light weight (or none for beginners) and bend your elbow to bring your hand toward your shoulder.',
            bodyPart: 'Elbow',
            sets: sets,
            reps: reps,
            durationSeconds: 60,
            difficultyLevel: difficultyLevel,
          ),
        ];
        break;

      case 'hip':
        exercises = [
          Exercise(
            id: 'hip_1',
            name: 'Hip Abduction',
            description:
                'Lie on your side and lift your top leg upward, away from your other leg.',
            bodyPart: 'Hip',
            sets: sets,
            reps: reps,
            durationSeconds: 30,
            difficultyLevel: difficultyLevel,
          ),
          Exercise(
            id: 'hip_2',
            name: 'Hip Flexion',
            description: 'Standing, lift your knee toward your chest.',
            bodyPart: 'Hip',
            sets: sets,
            reps: reps,
            durationSeconds: 45,
            difficultyLevel: difficultyLevel,
          ),
          Exercise(
            id: 'hip_3',
            name: 'Hip Extensions',
            description:
                'Standing, extend one leg behind you, keeping it straight.',
            bodyPart: 'Hip',
            sets: sets,
            reps: reps,
            durationSeconds: 60,
            difficultyLevel: difficultyLevel,
          ),
        ];
        break;

      case 'back':
        exercises = [
          Exercise(
            id: 'back_1',
            name: 'Prone Press-ups',
            description:
                'Lie face down and press up with your hands, keeping your hips on the ground.',
            bodyPart: 'Back',
            sets: sets,
            reps: reps,
            durationSeconds: 30,
            difficultyLevel: difficultyLevel,
          ),
          Exercise(
            id: 'back_2',
            name: 'Bridges',
            description:
                'Lie on your back with knees bent. Lift your hips forming a bridge.',
            bodyPart: 'Back',
            sets: sets,
            reps: reps,
            durationSeconds: 45,
            difficultyLevel: difficultyLevel,
          ),
          Exercise(
            id: 'back_3',
            name: 'Cat-Camel Stretch',
            description:
                'On hands and knees, alternate between arching and rounding your back.',
            bodyPart: 'Back',
            sets: sets,
            reps: reps,
            durationSeconds: 60,
            difficultyLevel: difficultyLevel,
          ),
        ];
        break;

      case 'neck':
        exercises = [
          Exercise(
            id: 'neck_1',
            name: 'Neck Rotation',
            description: 'Slowly turn your head to look over each shoulder.',
            bodyPart: 'Neck',
            sets: sets,
            reps: reps,
            durationSeconds: 30,
            difficultyLevel: difficultyLevel,
          ),
          Exercise(
            id: 'neck_2',
            name: 'Chin Tucks',
            description:
                'Pull your chin straight back, creating a "double chin."',
            bodyPart: 'Neck',
            sets: sets,
            reps: reps,
            durationSeconds: 45,
            difficultyLevel: difficultyLevel,
          ),
          Exercise(
            id: 'neck_3',
            name: 'Side Bend Stretch',
            description: 'Gently tilt your head toward each shoulder.',
            bodyPart: 'Neck',
            sets: sets,
            reps: reps,
            durationSeconds: 60,
            difficultyLevel: difficultyLevel,
          ),
        ];
        break;

      default:
        // Default exercises for other body parts
        exercises = [
          Exercise(
            id: 'general_1',
            name: 'Range of Motion Exercise',
            description:
                'Gently move the affected body part through its full range of motion, stopping when you feel pain or discomfort.',
            bodyPart: bodyPart,
            sets: sets,
            reps: reps,
            durationSeconds: 30,
            difficultyLevel: difficultyLevel,
          ),
          Exercise(
            id: 'general_2',
            name: 'Strengthening Exercise',
            description:
                'Using light resistance, perform targeted strengthening movements for the affected area.',
            bodyPart: bodyPart,
            sets: sets,
            reps: reps,
            durationSeconds: 45,
            difficultyLevel: difficultyLevel,
          ),
          Exercise(
            id: 'general_3',
            name: 'Stability Exercise',
            description:
                'Focus on maintaining balance and stability while engaging the affected area.',
            bodyPart: bodyPart,
            sets: sets,
            reps: reps - 2,
            durationSeconds: 60,
            difficultyLevel: difficultyLevel,
          ),
        ];
    }

    return exercises;
  }
}
